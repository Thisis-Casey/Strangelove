player_manager.AddValidModel( "Dr. Strangelove MGSPW", 		"models/tchaek/strangelove_mgspw/strangelove_mgspw_pm.mdl" );
list.Set( "PlayerOptionsModel", "Dr. Strangelove MGSPW", 	"models/tchaek/strangelove_mgspw/strangelove_mgspw_pm.mdl" );
player_manager.AddValidHands( "Dr. Strangelove MGSPW", "models/tchaek/strangelove_mgspw/strangelove_mgspw_pm_arms.mdl", 0, "00000000" )

-- Viewmodel, code credits: https://steamcommunity.com/id/libertyforce/

if CLIENT then

	local function Viewmodel( vm, ply, weapon )
		if CLIENT then
			if LocalPlayer():GetModel() == "models/tchaek/strangelove_mgspw/strangelove_mgspw_pm.mdl" then
				costume = LocalPlayer():GetBodygroup(2)
				local hands = LocalPlayer():GetHands()
				if ( weapon.UseHands || !weapon:IsScripted() ) then
					if ( IsValid( hands ) ) then
						hands:DrawModel()
						hands:SetBodygroup(0,costume)
					end
				end
			end
		end
	end
	hook.Add( "PostDrawViewModel", "strangelove_mgspw_viewmodel", Viewmodel )

end

--Add NPC
local NPC =
{
	Name = "Dr. Strangelove (MGS: Peace Walker)",
	Class = "npc_citizen",
	KeyValues = { citizentype = 4 },
	Model = "models/tchaek/strangelove_mgspw/strangelove_mgspw_pm.mdl",
	Category = "MGS: Peace Walker"
}

list.Set( "NPC", "npc_strangelove_mgspw", NPC )
